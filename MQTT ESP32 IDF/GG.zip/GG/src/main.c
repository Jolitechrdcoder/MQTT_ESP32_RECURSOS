#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "esp_wifi.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_event.h"
#include "esp_netif.h"
//#include "my_data.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"

#include "lwip/sockets.h"
#include "lwip/dns.h"
#include "lwip/netdb.h"

#include "esp_log.h"
#include "mqtt_client.h"
#include "MQTT\MQTT.h"
#include "WIFI\WIFI.h"
esp_mqtt_client_handle_t Client;
extern  typedefFLAGS Flag;
static void loop()
{

    while (1)
    {

    printf("LOOP");
 
    for (int i = 0; i <= 255; i++)
    {
        char send[2];  
        send[0] = i;
        send[1] ='\0';


        esp_mqtt_client_publish(Client, "my topic", send, 0, 2, 1);
    }
           
    vTaskDelay(5000 / portTICK_PERIOD_MS); 
    }
    
}
void app_main(void)
{
    nvs_flash_init();
    wifi_connection();
    while (!Flag.MQTT_READY);
    Client=Get_client();
    loop();
}