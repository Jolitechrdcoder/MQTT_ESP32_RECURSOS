
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "lwip/err.h"
#include "lwip/sys.h"
#include <driver/gpio.h>
//------------wifi y mqtt---------//
#include"wifi_jorge/wifi1.h"
#include"mqtt_jorge/mqtt1.h"
esp_mqtt_client_handle_t Client;
extern typedefFLAGS Flag;
int count=0;
char data[100];

void app_main(void)
{
    

      wifi_init_sta();
      while(!Flag.MQTT_READY);
      Client=Get_client();

      while (1)
      {
        count++;
        vTaskDelay(1000/portTICK_PERIOD_MS);
        sprintf(data,"%d",count);

        esp_mqtt_client_publish(Client, "data1", data, 0, 1, 0);
      }
      
}